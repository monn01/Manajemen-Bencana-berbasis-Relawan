package com.disasterrelief.controller;

import com.disasterrelief.model.*;
import com.disasterrelief.service.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML private BorderPane rootPane;
    @FXML private Label lblTotalRelawan;
    @FXML private Label lblRelawanTersedia;
    @FXML private Label lblTotalBencana;
    @FXML private Label lblBencanaAktif;
    @FXML private Label lblTotalTugas;
    @FXML private Label lblTugasBelumAssign;
    @FXML private TableView<Bencana> tableBencanaAktif;
    @FXML private TableColumn<Bencana, String> colBencana;
    @FXML private TableColumn<Bencana, String> colLokasi;
    @FXML private TableColumn<Bencana, String> colPrioritas;
    @FXML private TextArea txtSimulasiLog;

    private RelawanService relawanService;
    private BencanaService bencanaService;
    private TugasService tugasService;
    private PrioritasService prioritasService;
    private SimulasiService simulasiService;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initServices();
        initTableColumns();
        refreshDashboard();
    }

    private void initServices() {
        relawanService = new RelawanService();
        bencanaService = new BencanaService();
        tugasService = new TugasService();
        prioritasService = new PrioritasService(relawanService, tugasService, bencanaService);
        simulasiService = new SimulasiService(relawanService, tugasService, bencanaService, prioritasService);
    }

    private void initTableColumns() {
        colBencana.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNama()));
        colLokasi.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getLokasi()));
        colPrioritas.setCellValueFactory(data -> new SimpleStringProperty(
                String.valueOf(data.getValue().hitungTingkatPrioritas())
        ));
    }

    public void refreshDashboard() {
        // Refresh services
        relawanService.refresh();
        bencanaService.refresh();
        tugasService.refresh();

        // Update statistik
        lblTotalRelawan.setText(String.valueOf(relawanService.getAll().size()));
        lblRelawanTersedia.setText(String.valueOf(relawanService.getTersedia().size()));
        lblTotalBencana.setText(String.valueOf(bencanaService.getAll().size()));
        lblBencanaAktif.setText(String.valueOf(bencanaService.getAktif().size()));
        lblTotalTugas.setText(String.valueOf(tugasService.getAll().size()));
        lblTugasBelumAssign.setText(String.valueOf(tugasService.getBelumDitugaskan().size()));

        // Update table
        tableBencanaAktif.setItems(FXCollections.observableArrayList(bencanaService.getByPrioritas()));
    }

    @FXML
    private void onMenuDashboard() {
        try {
            Parent newDashboard = FXMLLoader.load(getClass().getResource("/com/disasterrelief/view/Dashboard.fxml"));
            rootPane.getScene().setRoot(newDashboard);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onMenuBencana() {
        loadView("view/BencanaView.fxml");
    }

    @FXML
    private void onMenuRelawan() {
        loadView("view/RelawanView.fxml");
    }

    @FXML
    private void onMenuTugas() {
        loadView("view/TugasView.fxml");
    }

    @FXML
    private void onGenerateDummy() {
        simulasiService.generateDummyData();
        refreshDashboard();
        log("Data dummy berhasil di-generate!");
    }

    @FXML
    private void onJalankanSimulasi() {
        SimulasiService.SimulasiResult result = simulasiService.jalankanSimulasi();
        refreshDashboard();
        log(result.toString());
    }

    @FXML
    private void onAutoAssign() {
        int count = prioritasService.autoAssignAll();
        refreshDashboard();
        log("Auto-assign selesai! " + count + " tugas berhasil ditugaskan.");
    }

    @FXML
    private void onResetData() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi Reset");
        confirm.setHeaderText("Reset semua data?");
        confirm.setContentText("Semua data relawan, bencana, dan tugas akan dihapus.");

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            simulasiService.resetData();
            refreshDashboard();
            log("Semua data berhasil di-reset!");
        }
    }

    private void loadView(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/disasterrelief/" + fxmlPath));
            Parent view = loader.load();

            // Pass services ke controller
            Object controller = loader.getController();
            if (controller instanceof RelawanController rc) {
                rc.setServices(relawanService, this);
            } else if (controller instanceof TugasController tc) {
                tc.setServices(tugasService, bencanaService, relawanService, this);
            } else if (controller instanceof BencanaController bc) {
                bc.setServices(bencanaService, this);
            }

            rootPane.setCenter(view);
        } catch (Exception e) {
            e.printStackTrace();
            log("Error loading view: " + e.getMessage());
        }
    }

    private void log(String message) {
        txtSimulasiLog.appendText(message + "\n\n");
    }
}