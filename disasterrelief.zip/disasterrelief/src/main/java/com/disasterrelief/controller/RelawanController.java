package com.disasterrelief.controller;

import com.disasterrelief.model.*;
import com.disasterrelief.model.enums.StatusRelawan;
import com.disasterrelief.service.RelawanService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class RelawanController implements Initializable {

    @FXML private TableView<Relawan> tableRelawan;
    @FXML private TableColumn<Relawan, String> colId;
    @FXML private TableColumn<Relawan, String> colNama;
    @FXML private TableColumn<Relawan, String> colTipe;
    @FXML private TableColumn<Relawan, String> colKeahlian;
    @FXML private TableColumn<Relawan, String> colStatus;
    @FXML private TableColumn<Relawan, String> colTelepon;
    @FXML private ComboBox<String> cmbFilterTipe;
    @FXML private ComboBox<StatusRelawan> cmbFilterStatus;

    private RelawanService relawanService;
    private DashboardController dashboardController;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initTableColumns();
        initFilters();
    }

    public void setServices(RelawanService relawanService, DashboardController dashboardController) {
        this.relawanService = relawanService;
        this.dashboardController = dashboardController;
        refreshTable();
    }

    private void initTableColumns() {
        colId.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getId()));
        colNama.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNama()));
        colTipe.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getClass().getSimpleName()));
        colKeahlian.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getKeahlian()));
        colStatus.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStatus().getDisplayName()));
        colTelepon.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNoTelepon()));
    }

    private void initFilters() {
        cmbFilterTipe.setItems(FXCollections.observableArrayList("Semua", "RelawanMedis", "RelawanEvakuasi", "RelawanLogistik"));
        cmbFilterTipe.setValue("Semua");

        cmbFilterStatus.setItems(FXCollections.observableArrayList(StatusRelawan.values()));
        cmbFilterStatus.getItems().add(0, null);
        cmbFilterStatus.setValue(null);
    }

    public void refreshTable() {
        if (relawanService == null) return;

        var list = relawanService.getAll();

        // Filter by tipe
        String tipe = cmbFilterTipe.getValue();
        if (tipe != null && !tipe.equals("Semua")) {
            list = list.stream()
                    .filter(r -> r.getClass().getSimpleName().equals(tipe))
                    .toList();
        }

        // Filter by status
        StatusRelawan status = cmbFilterStatus.getValue();
        if (status != null) {
            list = list.stream()
                    .filter(r -> r.getStatus() == status)
                    .toList();
        }

        tableRelawan.setItems(FXCollections.observableArrayList(list));
    }

    @FXML
    private void onFilter() {
        refreshTable();
    }

    @FXML
    private void onTambah() {
        Dialog<Relawan> dialog = createRelawanDialog(null);
        Optional<Relawan> result = dialog.showAndWait();

        result.ifPresent(relawan -> {
            relawanService.tambah(relawan);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onEdit() {
        Relawan selected = tableRelawan.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih relawan yang ingin diedit!");
            return;
        }

        Dialog<Relawan> dialog = createRelawanDialog(selected);
        Optional<Relawan> result = dialog.showAndWait();

        result.ifPresent(relawan -> {
            relawanService.update(relawan);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onHapus() {
        Relawan selected = tableRelawan.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih relawan yang ingin dihapus!");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi Hapus");
        confirm.setHeaderText("Hapus relawan " + selected.getNama() + "?");

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            relawanService.hapus(selected.getId());
            refreshTable();
            dashboardController.refreshDashboard();
        }
    }

    private Dialog<Relawan> createRelawanDialog(Relawan existing) {
        Dialog<Relawan> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Tambah Relawan" : "Edit Relawan");

        ButtonType saveButtonType = new ButtonType("Simpan", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        ComboBox<String> cmbTipe = new ComboBox<>(FXCollections.observableArrayList("RelawanMedis", "RelawanEvakuasi", "RelawanLogistik"));
        TextField txtNama = new TextField();
        TextField txtTelepon = new TextField();

        // Fields khusus per tipe
        VBox extraFields = new VBox(10);

        // Medis fields
        TextField txtSpesialisasi = new TextField();
        CheckBox chkSertifikat = new CheckBox("Memiliki Sertifikat");

        // Evakuasi fields
        CheckBox chkMenyetir = new CheckBox("Bisa Menyetir");
        CheckBox chkSAR = new CheckBox("Terlatih SAR");

        // Logistik fields
        CheckBox chkKendaraan = new CheckBox("Punya Kendaraan");
        TextField txtKapasitas = new TextField();
        txtKapasitas.setPromptText("Kapasitas angkut (kg)");

        cmbTipe.setOnAction(e -> {
            extraFields.getChildren().clear();
            switch (cmbTipe.getValue()) {
                case "RelawanMedis" -> extraFields.getChildren().addAll(
                        new Label("Spesialisasi:"), txtSpesialisasi, chkSertifikat
                );
                case "RelawanEvakuasi" -> extraFields.getChildren().addAll(chkMenyetir, chkSAR);
                case "RelawanLogistik" -> extraFields.getChildren().addAll(
                        chkKendaraan, new Label("Kapasitas Angkut:"), txtKapasitas
                );
            }
            dialog.getDialogPane().getScene().getWindow().sizeToScene();
        });

        grid.add(new Label("Tipe:"), 0, 0);
        grid.add(cmbTipe, 1, 0);
        grid.add(new Label("Nama:"), 0, 1);
        grid.add(txtNama, 1, 1);
        grid.add(new Label("No. Telepon:"), 0, 2);
        grid.add(txtTelepon, 1, 2);
        grid.add(extraFields, 0, 3, 2, 1);

        // Pre-fill jika edit
        if (existing != null) {
            txtNama.setText(existing.getNama());
            txtTelepon.setText(existing.getNoTelepon());

            if (existing instanceof RelawanMedis rm) {
                cmbTipe.setValue("RelawanMedis");
                txtSpesialisasi.setText(rm.getSpesialisasi());
                chkSertifikat.setSelected(rm.isMemilikiSertifikat());
            } else if (existing instanceof RelawanEvakuasi re) {
                cmbTipe.setValue("RelawanEvakuasi");
                chkMenyetir.setSelected(re.isBisaMenyetir());
                chkSAR.setSelected(re.isTerlatihSAR());
            } else if (existing instanceof RelawanLogistik rl) {
                cmbTipe.setValue("RelawanLogistik");
                chkKendaraan.setSelected(rl.isPunyaKendaraan());
                txtKapasitas.setText(String.valueOf(rl.getKapasitasAngkut()));
            }
            cmbTipe.setDisable(true);
            cmbTipe.fireEvent(new javafx.event.ActionEvent());
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String id = existing != null ? existing.getId() : null;

                return switch (cmbTipe.getValue()) {
                    case "RelawanMedis" -> new RelawanMedis(
                            id, txtNama.getText(), txtTelepon.getText(),
                            txtSpesialisasi.getText(), chkSertifikat.isSelected()
                    );
                    case "RelawanEvakuasi" -> new RelawanEvakuasi(
                            id, txtNama.getText(), txtTelepon.getText(),
                            chkMenyetir.isSelected(), chkSAR.isSelected()
                    );
                    case "RelawanLogistik" -> new RelawanLogistik(
                            id, txtNama.getText(), txtTelepon.getText(),
                            chkKendaraan.isSelected(),
                            txtKapasitas.getText().isBlank() ? 0 : Integer.parseInt(txtKapasitas.getText())
                    );
                    default -> null;
                };
            }
            return null;
        });

        return dialog;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Peringatan");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}