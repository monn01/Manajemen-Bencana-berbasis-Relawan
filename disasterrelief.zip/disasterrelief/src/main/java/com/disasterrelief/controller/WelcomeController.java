package com.disasterrelief.controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class WelcomeController {

    @FXML
    private Button btnMulai;

    @FXML
    private void onMulai() {
        try {
            // Load Dashboard
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/disasterrelief/view/Dashboard.fxml"));
            Parent dashboard = loader.load();

            // Get current stage
            Stage stage = (Stage) btnMulai.getScene().getWindow();

            // Set new scene
            Scene scene = new Scene(dashboard, 1200, 700);
            stage.setScene(scene);
            stage.setTitle("Sistem Manajemen Relawan Bencana");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onKeluar() {
        Platform.exit();
    }
}