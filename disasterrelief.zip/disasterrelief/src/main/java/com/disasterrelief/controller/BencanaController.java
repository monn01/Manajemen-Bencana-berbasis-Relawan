package com.disasterrelief.controller;

import com.disasterrelief.model.Bencana;
import com.disasterrelief.model.enums.JenisBencana;
import com.disasterrelief.service.BencanaService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

public class BencanaController implements Initializable {

    @FXML private TableView<Bencana> tableBencana;
    @FXML private TableColumn<Bencana, String> colId;
    @FXML private TableColumn<Bencana, String> colNama;
    @FXML private TableColumn<Bencana, String> colJenis;
    @FXML private TableColumn<Bencana, String> colLokasi;
    @FXML private TableColumn<Bencana, String> colTanggal;
    @FXML private TableColumn<Bencana, String> colKorban;
    @FXML private TableColumn<Bencana, String> colPrioritas;
    @FXML private TableColumn<Bencana, String> colStatus;
    @FXML private ComboBox<JenisBencana> cmbFilterJenis;
    @FXML private ComboBox<String> cmbFilterStatus;

    private BencanaService bencanaService;
    private DashboardController dashboardController;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initTableColumns();
        initFilters();
    }

    public void setServices(BencanaService bencanaService, DashboardController dashboardController) {
        this.bencanaService = bencanaService;
        this.dashboardController = dashboardController;
        refreshTable();
    }

    private void initTableColumns() {
        colId.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getId()));
        colNama.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNama()));
        colJenis.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getJenis().getDisplayName()));
        colLokasi.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getLokasi()));
        colTanggal.setCellValueFactory(data -> {
            LocalDateTime tgl = data.getValue().getTanggalKejadian();
            String formatted = tgl != null ? tgl.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")) : "-";
            return new SimpleStringProperty(formatted);
        });
        colKorban.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().getJumlahKorban())));
        colPrioritas.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().hitungTingkatPrioritas())));
        colStatus.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().isAktif() ? "Aktif" : "Nonaktif"));
    }

    private void initFilters() {
        cmbFilterJenis.setItems(FXCollections.observableArrayList(JenisBencana.values()));
        cmbFilterJenis.getItems().add(0, null);
        cmbFilterJenis.setValue(null);

        cmbFilterStatus.setItems(FXCollections.observableArrayList("Semua", "Aktif", "Nonaktif"));
        cmbFilterStatus.setValue("Semua");
    }

    public void refreshTable() {
        if (bencanaService == null) return;

        var list = bencanaService.getAll();

        // Filter by jenis
        JenisBencana jenis = cmbFilterJenis.getValue();
        if (jenis != null) {
            list = list.stream()
                    .filter(b -> b.getJenis() == jenis)
                    .toList();
        }

        // Filter by status
        String status = cmbFilterStatus.getValue();
        if (status != null && !status.equals("Semua")) {
            boolean aktif = status.equals("Aktif");
            list = list.stream()
                    .filter(b -> b.isAktif() == aktif)
                    .toList();
        }

        tableBencana.setItems(FXCollections.observableArrayList(list));
    }

    @FXML
    private void onFilter() {
        refreshTable();
    }

    @FXML
    private void onTambah() {
        Dialog<Bencana> dialog = createBencanaDialog(null);
        Optional<Bencana> result = dialog.showAndWait();

        result.ifPresent(bencana -> {
            bencanaService.tambah(bencana);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onEdit() {
        Bencana selected = tableBencana.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih bencana yang ingin diedit!");
            return;
        }

        Dialog<Bencana> dialog = createBencanaDialog(selected);
        Optional<Bencana> result = dialog.showAndWait();

        result.ifPresent(bencana -> {
            bencanaService.update(bencana);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onHapus() {
        Bencana selected = tableBencana.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih bencana yang ingin dihapus!");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi Hapus");
        confirm.setHeaderText("Hapus bencana " + selected.getNama() + "?");

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            bencanaService.hapus(selected.getId());
            refreshTable();
            dashboardController.refreshDashboard();
        }
    }

    @FXML
    private void onSetNonaktif() {
        Bencana selected = tableBencana.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih bencana yang ingin dinonaktifkan!");
            return;
        }

        if (!selected.isAktif()) {
            showAlert("Bencana sudah nonaktif!");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi Nonaktifkan");
        confirm.setHeaderText("Nonaktifkan bencana " + selected.getNama() + "?");
        confirm.setContentText("Bencana yang dinonaktifkan dianggap sudah selesai ditangani.");

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            bencanaService.setNonaktif(selected.getId());
            refreshTable();
            dashboardController.refreshDashboard();
        }
    }

    private Dialog<Bencana> createBencanaDialog(Bencana existing) {
        Dialog<Bencana> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Tambah Bencana" : "Edit Bencana");

        ButtonType saveButtonType = new ButtonType("Simpan", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField txtNama = new TextField();
        txtNama.setPrefWidth(300);
        ComboBox<JenisBencana> cmbJenis = new ComboBox<>(FXCollections.observableArrayList(JenisBencana.values()));
        TextField txtLokasi = new TextField();
        Spinner<Integer> spinKorban = new Spinner<>(0, 100000, 0);
        spinKorban.setEditable(true);

        grid.add(new Label("Nama Bencana:"), 0, 0);
        grid.add(txtNama, 1, 0);
        grid.add(new Label("Jenis:"), 0, 1);
        grid.add(cmbJenis, 1, 1);
        grid.add(new Label("Lokasi:"), 0, 2);
        grid.add(txtLokasi, 1, 2);
        grid.add(new Label("Jumlah Korban:"), 0, 3);
        grid.add(spinKorban, 1, 3);

        // Pre-fill jika edit
        if (existing != null) {
            txtNama.setText(existing.getNama());
            cmbJenis.setValue(existing.getJenis());
            txtLokasi.setText(existing.getLokasi());
            spinKorban.getValueFactory().setValue(existing.getJumlahKorban());
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                Bencana bencana = existing != null ? existing : new Bencana();
                bencana.setNama(txtNama.getText());
                bencana.setJenis(cmbJenis.getValue());
                bencana.setLokasi(txtLokasi.getText());
                bencana.setJumlahKorban(spinKorban.getValue());
                if (existing == null) {
                    bencana.setTanggalKejadian(LocalDateTime.now());
                }
                return bencana;
            }
            return null;
        });

        return dialog;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Peringatan");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}