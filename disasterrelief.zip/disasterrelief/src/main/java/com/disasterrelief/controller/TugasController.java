package com.disasterrelief.controller;

import com.disasterrelief.model.*;
import com.disasterrelief.model.enums.StatusTugas;
import com.disasterrelief.service.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ResourceBundle;

public class TugasController implements Initializable {

    @FXML private TableView<Tugas> tableTugas;
    @FXML private TableColumn<Tugas, String> colId;
    @FXML private TableColumn<Tugas, String> colDeskripsi;
    @FXML private TableColumn<Tugas, String> colBencana;
    @FXML private TableColumn<Tugas, String> colRelawan;
    @FXML private TableColumn<Tugas, String> colPrioritas;
    @FXML private TableColumn<Tugas, String> colStatus;
    @FXML private ComboBox<Bencana> cmbFilterBencana;
    @FXML private ComboBox<StatusTugas> cmbFilterStatus;

    private TugasService tugasService;
    private BencanaService bencanaService;
    private RelawanService relawanService;
    private DashboardController dashboardController;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initTableColumns();
    }

    public void setServices(TugasService tugasService, BencanaService bencanaService,
                            RelawanService relawanService, DashboardController dashboardController) {
        this.tugasService = tugasService;
        this.bencanaService = bencanaService;
        this.relawanService = relawanService;
        this.dashboardController = dashboardController;
        initFilters();
        refreshTable();
    }

    private void initTableColumns() {
        colId.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getId()));
        colDeskripsi.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getDeskripsi()));
        colPrioritas.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().getPrioritas())));
        colStatus.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStatus().getDisplayName()));

        colBencana.setCellValueFactory(data -> {
            Bencana b = bencanaService != null ? bencanaService.getById(data.getValue().getBencanaId()) : null;
            return new SimpleStringProperty(b != null ? b.getNama() : "-");
        });

        colRelawan.setCellValueFactory(data -> {
            String relawanId = data.getValue().getRelawanId();
            if (relawanId == null || relawanService == null) return new SimpleStringProperty("-");
            Relawan r = relawanService.getById(relawanId);
            return new SimpleStringProperty(r != null ? r.getNama() : "-");
        });
    }

    private void initFilters() {
        // Filter bencana
        cmbFilterBencana.setItems(FXCollections.observableArrayList(bencanaService.getAll()));
        cmbFilterBencana.getItems().add(0, null);
        cmbFilterBencana.setValue(null);
        cmbFilterBencana.setConverter(new javafx.util.StringConverter<>() {
            @Override
            public String toString(Bencana b) {
                return b == null ? "Semua Bencana" : b.getNama();
            }

            @Override
            public Bencana fromString(String s) {
                return null;
            }
        });

        // Filter status
        cmbFilterStatus.setItems(FXCollections.observableArrayList(StatusTugas.values()));
        cmbFilterStatus.getItems().add(0, null);
        cmbFilterStatus.setValue(null);
    }

    public void refreshTable() {
        if (tugasService == null) return;

        var list = tugasService.getAll();

        // Filter by bencana
        Bencana bencana = cmbFilterBencana.getValue();
        if (bencana != null) {
            list = list.stream()
                    .filter(t -> t.getBencanaId().equals(bencana.getId()))
                    .toList();
        }

        // Filter by status
        StatusTugas status = cmbFilterStatus.getValue();
        if (status != null) {
            list = list.stream()
                    .filter(t -> t.getStatus() == status)
                    .toList();
        }

        tableTugas.setItems(FXCollections.observableArrayList(list));
    }

    @FXML
    private void onFilter() {
        refreshTable();
    }

    @FXML
    private void onTambah() {
        Dialog<Tugas> dialog = createTugasDialog(null);
        Optional<Tugas> result = dialog.showAndWait();

        result.ifPresent(tugas -> {
            tugasService.tambah(tugas);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onEdit() {
        Tugas selected = tableTugas.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih tugas yang ingin diedit!");
            return;
        }

        Dialog<Tugas> dialog = createTugasDialog(selected);
        Optional<Tugas> result = dialog.showAndWait();

        result.ifPresent(tugas -> {
            tugasService.update(tugas);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onHapus() {
        Tugas selected = tableTugas.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih tugas yang ingin dihapus!");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi Hapus");
        confirm.setHeaderText("Hapus tugas ini?");

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            tugasService.hapus(selected.getId());
            refreshTable();
            dashboardController.refreshDashboard();
        }
    }

    @FXML
    private void onAssignRelawan() {
        Tugas selected = tableTugas.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih tugas yang ingin di-assign!");
            return;
        }

        if (selected.getStatus() != StatusTugas.BELUM_DITUGASKAN) {
            showAlert("Tugas sudah ditugaskan atau selesai!");
            return;
        }

        var tersedia = relawanService.getTersedia();
        if (tersedia.isEmpty()) {
            showAlert("Tidak ada relawan yang tersedia!");
            return;
        }

        ChoiceDialog<Relawan> dialog = new ChoiceDialog<>(tersedia.get(0), tersedia);
        dialog.setTitle("Assign Relawan");
        dialog.setHeaderText("Pilih relawan untuk tugas: " + selected.getDeskripsi());
        dialog.setContentText("Relawan:");

        dialog.showAndWait().ifPresent(relawan -> {
            tugasService.assignRelawan(selected.getId(), relawan.getId());
            relawanService.updateStatus(relawan.getId(), com.disasterrelief.model.enums.StatusRelawan.DITUGASKAN);
            refreshTable();
            dashboardController.refreshDashboard();
        });
    }

    @FXML
    private void onSelesaikan() {
        Tugas selected = tableTugas.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Pilih tugas yang ingin diselesaikan!");
            return;
        }

        if (selected.getStatus() != StatusTugas.SEDANG_DIKERJAKAN) {
            showAlert("Tugas belum ditugaskan atau sudah selesai!");
            return;
        }

        // Kembalikan status relawan
        if (selected.getRelawanId() != null) {
            relawanService.updateStatus(selected.getRelawanId(), com.disasterrelief.model.enums.StatusRelawan.TERSEDIA);
        }

        tugasService.selesaikanTugas(selected.getId());
        refreshTable();
        dashboardController.refreshDashboard();
    }

    private Dialog<Tugas> createTugasDialog(Tugas existing) {
        Dialog<Tugas> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Tambah Tugas" : "Edit Tugas");

        ButtonType saveButtonType = new ButtonType("Simpan", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField txtDeskripsi = new TextField();
        txtDeskripsi.setPrefWidth(300);
        ComboBox<Bencana> cmbBencana = new ComboBox<>(FXCollections.observableArrayList(bencanaService.getAktif()));
        cmbBencana.setConverter(new javafx.util.StringConverter<>() {
            @Override
            public String toString(Bencana b) {
                return b == null ? "" : b.getNama();
            }

            @Override
            public Bencana fromString(String s) {
                return null;
            }
        });
        Spinner<Integer> spinPrioritas = new Spinner<>(1, 10, 5);

        grid.add(new Label("Deskripsi:"), 0, 0);
        grid.add(txtDeskripsi, 1, 0);
        grid.add(new Label("Bencana:"), 0, 1);
        grid.add(cmbBencana, 1, 1);
        grid.add(new Label("Prioritas (1-10):"), 0, 2);
        grid.add(spinPrioritas, 1, 2);

        // Pre-fill jika edit
        if (existing != null) {
            txtDeskripsi.setText(existing.getDeskripsi());
            spinPrioritas.getValueFactory().setValue(existing.getPrioritas());
            Bencana b = bencanaService.getById(existing.getBencanaId());
            cmbBencana.setValue(b);
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                Tugas tugas = existing != null ? existing : new Tugas();
                tugas.setDeskripsi(txtDeskripsi.getText());
                tugas.setBencanaId(cmbBencana.getValue() != null ? cmbBencana.getValue().getId() : null);
                tugas.setPrioritas(spinPrioritas.getValue());
                tugas.setDeadline(LocalDateTime.now().plusDays(1));
                return tugas;
            }
            return null;
        });

        return dialog;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Peringatan");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}