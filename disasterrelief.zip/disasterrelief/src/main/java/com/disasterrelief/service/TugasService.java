package com.disasterrelief.service;

import com.disasterrelief.model.Tugas;
import com.disasterrelief.model.enums.StatusTugas;
import com.disasterrelief.util.JsonUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public class TugasService {

    private List<Tugas> tugasList;

    public TugasService() {
        this.tugasList = JsonUtil.loadTugas();
    }

    public List<Tugas> getAll() {
        return new ArrayList<>(tugasList);
    }

    public Tugas getById(String id) {
        return tugasList.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Tugas> getByBencana(String bencanaId) {
        return tugasList.stream()
                .filter(t -> t.getBencanaId().equals(bencanaId))
                .toList();
    }

    public List<Tugas> getByRelawan(String relawanId) {
        return tugasList.stream()
                .filter(t -> relawanId.equals(t.getRelawanId()))
                .toList();
    }

    public List<Tugas> getByStatus(StatusTugas status) {
        return tugasList.stream()
                .filter(t -> t.getStatus() == status)
                .toList();
    }

    public List<Tugas> getBelumDitugaskan() {
        return getByStatus(StatusTugas.BELUM_DITUGASKAN);
    }

    public List<Tugas> getByPrioritas() {
        return tugasList.stream()
                .sorted(Comparator.comparingInt(Tugas::getPrioritas).reversed())
                .toList();
    }

    public void tambah(Tugas tugas) {
        if (tugas.getId() == null || tugas.getId().isBlank()) {
            tugas.setId(generateId());
        }
        tugasList.add(tugas);
        save();
    }

    public void update(Tugas tugas) {
        for (int i = 0; i < tugasList.size(); i++) {
            if (tugasList.get(i).getId().equals(tugas.getId())) {
                tugasList.set(i, tugas);
                save();
                return;
            }
        }
    }

    public void hapus(String id) {
        tugasList.removeIf(t -> t.getId().equals(id));
        save();
    }

    public void assignRelawan(String tugasId, String relawanId) {
        Tugas tugas = getById(tugasId);
        if (tugas != null) {
            tugas.setRelawanId(relawanId);
            tugas.setStatus(StatusTugas.SEDANG_DIKERJAKAN);
            save();
        }
    }

    public void selesaikanTugas(String tugasId) {
        Tugas tugas = getById(tugasId);
        if (tugas != null) {
            tugas.setStatus(StatusTugas.SELESAI);
            save();
        }
    }

    private String generateId() {
        return "TGS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public void save() {
        JsonUtil.saveTugas(tugasList);
    }

    public void refresh() {
        this.tugasList = JsonUtil.loadTugas();
    }
}