package com.disasterrelief.service;

import com.disasterrelief.model.Bencana;
import com.disasterrelief.util.JsonUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class BencanaService {

    private List<Bencana> bencanaList;

    public BencanaService() {
        this.bencanaList = JsonUtil.loadBencana();
    }

    public List<Bencana> getAll() {
        return new ArrayList<>(bencanaList);
    }

    public Bencana getById(String id) {
        return bencanaList.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Bencana> getAktif() {
        return bencanaList.stream()
                .filter(Bencana::isAktif)
                .toList();
    }

    public List<Bencana> getByPrioritas() {
        return bencanaList.stream()
                .filter(Bencana::isAktif)
                .sorted((a, b) -> Integer.compare(b.hitungTingkatPrioritas(), a.hitungTingkatPrioritas()))
                .toList();
    }

    public void tambah(Bencana bencana) {
        if (bencana.getId() == null || bencana.getId().isBlank()) {
            bencana.setId(generateId());
        }
        bencanaList.add(bencana);
        save();
    }

    public void update(Bencana bencana) {
        for (int i = 0; i < bencanaList.size(); i++) {
            if (bencanaList.get(i).getId().equals(bencana.getId())) {
                bencanaList.set(i, bencana);
                save();
                return;
            }
        }
    }

    public void hapus(String id) {
        bencanaList.removeIf(b -> b.getId().equals(id));
        save();
    }

    public void setNonaktif(String id) {
        Bencana bencana = getById(id);
        if (bencana != null) {
            bencana.setAktif(false);
            save();
        }
    }

    private String generateId() {
        return "BNC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public void save() {
        JsonUtil.saveBencana(bencanaList);
    }

    public void refresh() {
        this.bencanaList = JsonUtil.loadBencana();
    }
}