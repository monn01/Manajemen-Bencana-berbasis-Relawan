package com.disasterrelief.service;

import com.disasterrelief.model.*;
import com.disasterrelief.model.enums.JenisBencana;
import com.disasterrelief.model.enums.StatusRelawan;
import com.disasterrelief.model.enums.StatusTugas;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SimulasiService {

    private final RelawanService relawanService;
    private final TugasService tugasService;
    private final BencanaService bencanaService;
    private final PrioritasService prioritasService;
    private final Random random = new Random();

    public SimulasiService(RelawanService relawanService, TugasService tugasService,
                           BencanaService bencanaService, PrioritasService prioritasService) {
        this.relawanService = relawanService;
        this.tugasService = tugasService;
        this.bencanaService = bencanaService;
        this.prioritasService = prioritasService;
    }

    // Generate data dummy untuk testing
    public void generateDummyData() {
        generateDummyRelawan();
        generateDummyBencana();
        generateDummyTugas();
    }

    private void generateDummyRelawan() {
        // Relawan Medis
        relawanService.tambah(new RelawanMedis(null, "Dr. Andi Pratama", "081234567890", "Bedah", true));
        relawanService.tambah(new RelawanMedis(null, "Siti Nurhaliza", "081234567891", "Umum", true));
        relawanService.tambah(new RelawanMedis(null, "Budi Santoso", "081234567892", "Anak", false));

        // Relawan Evakuasi
        relawanService.tambah(new RelawanEvakuasi(null, "Joko Widodo", "081234567893", true, true));
        relawanService.tambah(new RelawanEvakuasi(null, "Mega Wati", "081234567894", true, false));
        relawanService.tambah(new RelawanEvakuasi(null, "Agus Salim", "081234567895", false, true));

        // Relawan Logistik
        relawanService.tambah(new RelawanLogistik(null, "Dewi Persik", "081234567896", true, 1000));
        relawanService.tambah(new RelawanLogistik(null, "Rano Karno", "081234567897", true, 500));
        relawanService.tambah(new RelawanLogistik(null, "Sule Sutisna", "081234567898", false, 200));
    }

    private void generateDummyBencana() {
        bencanaService.tambah(new Bencana(null, "Gempa Cianjur", JenisBencana.GEMPA_BUMI,
                "Cianjur, Jawa Barat", LocalDateTime.now().minusDays(2), 150));

        bencanaService.tambah(new Bencana(null, "Banjir Jakarta", JenisBencana.BANJIR,
                "Jakarta Selatan", LocalDateTime.now().minusDays(1), 50));

        bencanaService.tambah(new Bencana(null, "Kebakaran Hutan Kalimantan", JenisBencana.KEBAKARAN,
                "Kalimantan Tengah", LocalDateTime.now().minusHours(12), 20));
    }

    private void generateDummyTugas() {
        List<Bencana> bencanaList = bencanaService.getAll();

        if (!bencanaList.isEmpty()) {
            Bencana gempa = bencanaList.get(0);
            tugasService.tambah(new Tugas(null, "Evakuasi korban terjebak", gempa.getId(), 5,
                    LocalDateTime.now().plusHours(6)));
            tugasService.tambah(new Tugas(null, "Penanganan medis darurat", gempa.getId(), 5,
                    LocalDateTime.now().plusHours(4)));
            tugasService.tambah(new Tugas(null, "Distribusi makanan dan air", gempa.getId(), 4,
                    LocalDateTime.now().plusHours(12)));
        }

        if (bencanaList.size() > 1) {
            Bencana banjir = bencanaList.get(1);
            tugasService.tambah(new Tugas(null, "Evakuasi warga terdampak", banjir.getId(), 4,
                    LocalDateTime.now().plusHours(8)));
            tugasService.tambah(new Tugas(null, "Penyediaan tempat pengungsian", banjir.getId(), 3,
                    LocalDateTime.now().plusHours(10)));
        }
    }

    // Simulasi penugasan otomatis
    public SimulasiResult jalankanSimulasi() {
        SimulasiResult result = new SimulasiResult();

        result.totalTugasBelumAssign = tugasService.getBelumDitugaskan().size();
        result.totalRelawanTersedia = relawanService.getTersedia().size();

        result.berhasilDitugaskan = prioritasService.autoAssignAll();

        result.tugasTersisa = tugasService.getBelumDitugaskan().size();
        result.relawanTersisa = relawanService.getTersedia().size();

        return result;
    }

    // Selesaikan tugas dan kembalikan status relawan
    public void selesaikanTugas(String tugasId) {
        Tugas tugas = tugasService.getById(tugasId);
        if (tugas != null && tugas.getRelawanId() != null) {
            tugasService.selesaikanTugas(tugasId);
            relawanService.updateStatus(tugas.getRelawanId(), StatusRelawan.TERSEDIA);
        }
    }

    // Reset semua data
    public void resetData() {
        // Hapus semua tugas
        for (Tugas t : tugasService.getAll()) {
            tugasService.hapus(t.getId());
        }

        // Hapus semua bencana
        for (Bencana b : bencanaService.getAll()) {
            bencanaService.hapus(b.getId());
        }

        // Hapus semua relawan
        for (Relawan r : relawanService.getAll()) {
            relawanService.hapus(r.getId());
        }
    }

    // Inner class untuk hasil simulasi
    public static class SimulasiResult {
        public int totalTugasBelumAssign;
        public int totalRelawanTersedia;
        public int berhasilDitugaskan;
        public int tugasTersisa;
        public int relawanTersisa;

        @Override
        public String toString() {
            return String.format(
                    "=== HASIL SIMULASI ===\n" +
                            "Tugas belum ditugaskan: %d\n" +
                            "Relawan tersedia: %d\n" +
                            "Berhasil ditugaskan: %d\n" +
                            "Tugas tersisa: %d\n" +
                            "Relawan tersisa: %d",
                    totalTugasBelumAssign, totalRelawanTersedia,
                    berhasilDitugaskan, tugasTersisa, relawanTersisa
            );
        }
    }
}