package com.disasterrelief.service;

import com.disasterrelief.model.*;
import com.disasterrelief.model.enums.StatusRelawan;
import com.disasterrelief.model.enums.StatusTugas;

import java.util.Comparator;
import java.util.List;

public class PrioritasService {

    private final RelawanService relawanService;
    private final TugasService tugasService;
    private final BencanaService bencanaService;

    public PrioritasService(RelawanService relawanService, TugasService tugasService, BencanaService bencanaService) {
        this.relawanService = relawanService;
        this.tugasService = tugasService;
        this.bencanaService = bencanaService;
    }

    // Cari relawan terbaik untuk tugas tertentu
    public Relawan cariRelawanTerbaik(Tugas tugas) {
        List<Relawan> tersedia = relawanService.getTersedia();

        if (tersedia.isEmpty()) {
            return null;
        }

        // Sort berdasarkan prioritas keahlian (descending)
        return tersedia.stream()
                .max(Comparator.comparingInt(Relawan::getPrioritasKeahlian))
                .orElse(null);
    }

    // Cari relawan terbaik berdasarkan tipe untuk bencana tertentu
    public Relawan cariRelawanTerbaikByTipe(Class<? extends Relawan> tipe) {
        return relawanService.getTersedia().stream()
                .filter(tipe::isInstance)
                .max(Comparator.comparingInt(Relawan::getPrioritasKeahlian))
                .orElse(null);
    }

    // Auto-assign relawan ke tugas berdasarkan prioritas
    public boolean autoAssign(String tugasId) {
        Tugas tugas = tugasService.getById(tugasId);
        if (tugas == null || tugas.getStatus() != StatusTugas.BELUM_DITUGASKAN) {
            return false;
        }

        Relawan relawan = cariRelawanTerbaik(tugas);
        if (relawan == null) {
            return false;
        }

        // Assign relawan ke tugas
        tugasService.assignRelawan(tugasId, relawan.getId());
        relawanService.updateStatus(relawan.getId(), StatusRelawan.DITUGASKAN);

        return true;
    }

    // Auto-assign semua tugas yang belum ditugaskan
    public int autoAssignAll() {
        List<Tugas> belumDitugaskan = tugasService.getBelumDitugaskan();
        int berhasilAssign = 0;

        // Sort by prioritas (highest first)
        List<Tugas> sorted = belumDitugaskan.stream()
                .sorted(Comparator.comparingInt(Tugas::getPrioritas).reversed())
                .toList();

        for (Tugas tugas : sorted) {
            if (autoAssign(tugas.getId())) {
                berhasilAssign++;
            }
        }

        return berhasilAssign;
    }

    // Hitung skor prioritas untuk tugas berdasarkan bencana
    public int hitungSkorPrioritas(Tugas tugas) {
        Bencana bencana = bencanaService.getById(tugas.getBencanaId());
        if (bencana == null) {
            return tugas.getPrioritas();
        }

        int skor = tugas.getPrioritas();
        skor += bencana.hitungTingkatPrioritas();

        return skor;
    }

    // Dapatkan tugas terurut berdasarkan skor prioritas gabungan
    public List<Tugas> getTugasBySkoPrioritas() {
        return tugasService.getAll().stream()
                .sorted((a, b) -> Integer.compare(hitungSkorPrioritas(b), hitungSkorPrioritas(a)))
                .toList();
    }
}