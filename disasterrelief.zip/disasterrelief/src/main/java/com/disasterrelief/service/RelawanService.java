package com.disasterrelief.service;

import com.disasterrelief.model.*;
import com.disasterrelief.model.enums.StatusRelawan;
import com.disasterrelief.util.JsonUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class RelawanService {

    private List<Relawan> relawanList;

    public RelawanService() {
        this.relawanList = JsonUtil.loadRelawan();
    }

    public List<Relawan> getAll() {
        return new ArrayList<>(relawanList);
    }

    public Relawan getById(String id) {
        return relawanList.stream()
                .filter(r -> r.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Relawan> getByStatus(StatusRelawan status) {
        return relawanList.stream()
                .filter(r -> r.getStatus() == status)
                .toList();
    }

    public List<Relawan> getTersedia() {
        return getByStatus(StatusRelawan.TERSEDIA);
    }

    public void tambah(Relawan relawan) {
        if (relawan.getId() == null || relawan.getId().isBlank()) {
            relawan.setId(generateId());
        }
        relawanList.add(relawan);
        save();
    }

    public void update(Relawan relawan) {
        for (int i = 0; i < relawanList.size(); i++) {
            if (relawanList.get(i).getId().equals(relawan.getId())) {
                relawanList.set(i, relawan);
                save();
                return;
            }
        }
    }

    public void hapus(String id) {
        relawanList.removeIf(r -> r.getId().equals(id));
        save();
    }

    public void updateStatus(String id, StatusRelawan status) {
        Relawan relawan = getById(id);
        if (relawan != null) {
            relawan.setStatus(status);
            save();
        }
    }

    private String generateId() {
        return "REL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public void save() {
        JsonUtil.saveRelawan(relawanList);
    }

    public void refresh() {
        this.relawanList = JsonUtil.loadRelawan();
    }
}