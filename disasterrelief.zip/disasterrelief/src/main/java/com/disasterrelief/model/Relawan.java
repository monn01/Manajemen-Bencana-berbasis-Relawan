package com.disasterrelief.model;

import com.disasterrelief.model.enums.StatusRelawan;

public abstract class Relawan {
    private String id;
    private String nama;
    private String noTelepon;
    private StatusRelawan status;

    public Relawan() {
        this.status = StatusRelawan.TERSEDIA;
    }

    public Relawan(String id, String nama, String noTelepon) {
        this.id = id;
        this.nama = nama;
        this.noTelepon = noTelepon;
        this.status = StatusRelawan.TERSEDIA;
    }

    // Abstract method
    public abstract String getKeahlian();
    public abstract int getPrioritasKeahlian();

    // Getters & Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }

    public StatusRelawan getStatus() {
        return status;
    }

    public void setStatus(StatusRelawan status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return nama + " (" + getKeahlian() + ")";
    }
}