package com.disasterrelief.model;

public class RelawanLogistik extends Relawan {
    private boolean punyaKendaraan;
    private int kapasitasAngkut; // dalam kg

    public RelawanLogistik() {
        super();
    }

    public RelawanLogistik(String id, String nama, String noTelepon, boolean punyaKendaraan, int kapasitasAngkut) {
        super(id, nama, noTelepon);
        this.punyaKendaraan = punyaKendaraan;
        this.kapasitasAngkut = kapasitasAngkut;
    }

    @Override
    public String getKeahlian() {
        return "Logistik" + (punyaKendaraan ? " (Punya Kendaraan)" : "");
    }

    @Override
    public int getPrioritasKeahlian() {
        int prioritas = 2;
        if (punyaKendaraan) prioritas += 2;
        if (kapasitasAngkut > 500) prioritas++;
        return prioritas;
    }

    // Getters & Setters
    public boolean isPunyaKendaraan() {
        return punyaKendaraan;
    }

    public void setPunyaKendaraan(boolean punyaKendaraan) {
        this.punyaKendaraan = punyaKendaraan;
    }

    public int getKapasitasAngkut() {
        return kapasitasAngkut;
    }

    public void setKapasitasAngkut(int kapasitasAngkut) {
        this.kapasitasAngkut = kapasitasAngkut;
    }
}