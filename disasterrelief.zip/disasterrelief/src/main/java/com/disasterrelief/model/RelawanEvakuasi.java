package com.disasterrelief.model;

public class RelawanEvakuasi extends Relawan {
    private boolean bisaMenyetir;
    private boolean terlatihSAR;

    public RelawanEvakuasi() {
        super();
    }

    public RelawanEvakuasi(String id, String nama, String noTelepon, boolean bisaMenyetir, boolean terlatihSAR) {
        super(id, nama, noTelepon);
        this.bisaMenyetir = bisaMenyetir;
        this.terlatihSAR = terlatihSAR;
    }

    @Override
    public String getKeahlian() {
        return "Evakuasi" + (terlatihSAR ? " (SAR)" : "");
    }

    @Override
    public int getPrioritasKeahlian() {
        int prioritas = 2;
        if (bisaMenyetir) prioritas++;
        if (terlatihSAR) prioritas += 2;
        return prioritas;
    }

    // Getters & Setters
    public boolean isBisaMenyetir() {
        return bisaMenyetir;
    }

    public void setBisaMenyetir(boolean bisaMenyetir) {
        this.bisaMenyetir = bisaMenyetir;
    }

    public boolean isTerlatihSAR() {
        return terlatihSAR;
    }

    public void setTerlatihSAR(boolean terlatihSAR) {
        this.terlatihSAR = terlatihSAR;
    }
}