package com.disasterrelief.model;

public class RelawanMedis extends Relawan {
    private String spesialisasi;
    private boolean memilikiSertifikat;

    public RelawanMedis() {
        super();
    }

    public RelawanMedis(String id, String nama, String noTelepon, String spesialisasi, boolean memilikiSertifikat) {
        super(id, nama, noTelepon);
        this.spesialisasi = spesialisasi;
        this.memilikiSertifikat = memilikiSertifikat;
    }

    @Override
    public String getKeahlian() {
        return "Medis - " + spesialisasi;
    }

    @Override
    public int getPrioritasKeahlian() {
        return memilikiSertifikat ? 5 : 3;
    }

    // Getters & Setters
    public String getSpesialisasi() {
        return spesialisasi;
    }

    public void setSpesialisasi(String spesialisasi) {
        this.spesialisasi = spesialisasi;
    }

    public boolean isMemilikiSertifikat() {
        return memilikiSertifikat;
    }

    public void setMemilikiSertifikat(boolean memilikiSertifikat) {
        this.memilikiSertifikat = memilikiSertifikat;
    }
}