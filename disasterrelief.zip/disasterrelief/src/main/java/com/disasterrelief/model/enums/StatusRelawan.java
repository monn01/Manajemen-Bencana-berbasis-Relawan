package com.disasterrelief.model.enums;

public enum StatusRelawan {
    TERSEDIA("Tersedia"),
    DITUGASKAN("Sedang Ditugaskan"),
    ISTIRAHAT("Istirahat");

    private final String displayName;

    StatusRelawan(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}