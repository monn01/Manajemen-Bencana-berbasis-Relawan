package com.disasterrelief.model;

import com.disasterrelief.model.enums.StatusTugas;
import java.time.LocalDateTime;

public class Tugas {
    private String id;
    private String deskripsi;
    private String bencanaId;
    private String relawanId;
    private StatusTugas status;
    private int prioritas;
    private LocalDateTime deadline;
    private LocalDateTime tanggalDibuat;

    public Tugas() {
        this.status = StatusTugas.BELUM_DITUGASKAN;
        this.tanggalDibuat = LocalDateTime.now();
    }

    public Tugas(String id, String deskripsi, String bencanaId, int prioritas, LocalDateTime deadline) {
        this.id = id;
        this.deskripsi = deskripsi;
        this.bencanaId = bencanaId;
        this.prioritas = prioritas;
        this.deadline = deadline;
        this.status = StatusTugas.BELUM_DITUGASKAN;
        this.tanggalDibuat = LocalDateTime.now();
    }

    // Getters & Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getBencanaId() {
        return bencanaId;
    }

    public void setBencanaId(String bencanaId) {
        this.bencanaId = bencanaId;
    }

    public String getRelawanId() {
        return relawanId;
    }

    public void setRelawanId(String relawanId) {
        this.relawanId = relawanId;
    }

    public StatusTugas getStatus() {
        return status;
    }

    public void setStatus(StatusTugas status) {
        this.status = status;
    }

    public int getPrioritas() {
        return prioritas;
    }

    public void setPrioritas(int prioritas) {
        this.prioritas = prioritas;
    }

    public LocalDateTime getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }

    public LocalDateTime getTanggalDibuat() {
        return tanggalDibuat;
    }

    public void setTanggalDibuat(LocalDateTime tanggalDibuat) {
        this.tanggalDibuat = tanggalDibuat;
    }
}