package com.disasterrelief.model.enums;

public enum StatusTugas {
    BELUM_DITUGASKAN("Belum Ditugaskan"),
    SEDANG_DIKERJAKAN("Sedang Dikerjakan"),
    SELESAI("Selesai");

    private final String displayName;

    StatusTugas(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}