package com.disasterrelief.model.enums;

public enum JenisBencana {
    GEMPA_BUMI("Gempa Bumi", 5),
    BANJIR("Banjir", 4),
    KEBAKARAN("Kebakaran", 4),
    TANAH_LONGSOR("Tanah Longsor", 3),
    TSUNAMI("Tsunami", 5),
    ANGIN_TOPAN("Angin Topan", 3);

    private final String displayName;
    private final int tingkatBahaya;

    JenisBencana(String displayName, int tingkatBahaya) {
        this.displayName = displayName;
        this.tingkatBahaya = tingkatBahaya;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getTingkatBahaya() {
        return tingkatBahaya;
    }
}