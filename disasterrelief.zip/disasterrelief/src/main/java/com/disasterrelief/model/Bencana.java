package com.disasterrelief.model;

import com.disasterrelief.model.enums.JenisBencana;
import java.time.LocalDateTime;

public class Bencana {
    private String id;
    private String nama;
    private JenisBencana jenis;
    private String lokasi;
    private LocalDateTime tanggalKejadian;
    private int jumlahKorban;
    private boolean aktif;

    public Bencana() {
        this.aktif = true;
    }

    public Bencana(String id, String nama, JenisBencana jenis, String lokasi, LocalDateTime tanggalKejadian, int jumlahKorban) {
        this.id = id;
        this.nama = nama;
        this.jenis = jenis;
        this.lokasi = lokasi;
        this.tanggalKejadian = tanggalKejadian;
        this.jumlahKorban = jumlahKorban;
        this.aktif = true;
    }

    public int hitungTingkatPrioritas() {
        int prioritas = jenis.getTingkatBahaya();
        if (jumlahKorban > 100) prioritas += 2;
        else if (jumlahKorban > 50) prioritas += 1;
        return Math.min(prioritas, 10);
    }

    // Getters & Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public JenisBencana getJenis() {
        return jenis;
    }

    public void setJenis(JenisBencana jenis) {
        this.jenis = jenis;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public LocalDateTime getTanggalKejadian() {
        return tanggalKejadian;
    }

    public void setTanggalKejadian(LocalDateTime tanggalKejadian) {
        this.tanggalKejadian = tanggalKejadian;
    }

    public int getJumlahKorban() {
        return jumlahKorban;
    }

    public void setJumlahKorban(int jumlahKorban) {
        this.jumlahKorban = jumlahKorban;
    }

    public boolean isAktif() {
        return aktif;
    }

    public void setAktif(boolean aktif) {
        this.aktif = aktif;
    }
}