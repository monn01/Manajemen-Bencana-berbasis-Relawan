package com.disasterrelief.util;

import com.disasterrelief.model.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class JsonUtil {

    private static final String DATA_PATH = "src/main/resources/com/disasterrelief/data/";
    private static final Gson gson;

    static {
        gson = new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
                .create();
    }

    // ==================== RELAWAN ====================
    public static List<Relawan> loadRelawan() {
        try {
            String json = Files.readString(Path.of(DATA_PATH + "relawan.json"));
            if (json == null || json.isBlank() || json.trim().equals("[]")) {
                return new ArrayList<>();
            }

            JsonArray array = JsonParser.parseString(json).getAsJsonArray();
            List<Relawan> list = new ArrayList<>();

            for (JsonElement element : array) {
                JsonObject obj = element.getAsJsonObject();
                String tipe = obj.get("tipe").getAsString();
                JsonObject data = obj.get("data").getAsJsonObject();

                Relawan relawan = switch (tipe) {
                    case "RelawanMedis" -> gson.fromJson(data, RelawanMedis.class);
                    case "RelawanEvakuasi" -> gson.fromJson(data, RelawanEvakuasi.class);
                    case "RelawanLogistik" -> gson.fromJson(data, RelawanLogistik.class);
                    default -> null;
                };

                if (relawan != null) {
                    list.add(relawan);
                }
            }
            return list;
        } catch (Exception e) {
            System.err.println("Error loading relawan: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public static void saveRelawan(List<Relawan> relawanList) {
        try {
            JsonArray array = new JsonArray();

            for (Relawan r : relawanList) {
                JsonObject obj = new JsonObject();
                obj.addProperty("tipe", r.getClass().getSimpleName());
                obj.add("data", gson.toJsonTree(r));
                array.add(obj);
            }

            String json = gson.toJson(array);
            Files.writeString(Path.of(DATA_PATH + "relawan.json"), json);
        } catch (IOException e) {
            System.err.println("Error saving relawan: " + e.getMessage());
        }
    }

    // ==================== BENCANA ====================
    public static List<Bencana> loadBencana() {
        try {
            String json = Files.readString(Path.of(DATA_PATH + "bencana.json"));
            if (json == null || json.isBlank() || json.trim().equals("[]")) {
                return new ArrayList<>();
            }
            Type listType = new TypeToken<List<Bencana>>(){}.getType();
            List<Bencana> list = gson.fromJson(json, listType);
            return list != null ? list : new ArrayList<>();
        } catch (Exception e) {
            System.err.println("Error loading bencana: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public static void saveBencana(List<Bencana> bencanaList) {
        try {
            String json = gson.toJson(bencanaList);
            Files.writeString(Path.of(DATA_PATH + "bencana.json"), json);
        } catch (IOException e) {
            System.err.println("Error saving bencana: " + e.getMessage());
        }
    }

    // ==================== TUGAS ====================
    public static List<Tugas> loadTugas() {
        try {
            String json = Files.readString(Path.of(DATA_PATH + "tugas.json"));
            if (json == null || json.isBlank() || json.trim().equals("[]")) {
                return new ArrayList<>();
            }
            Type listType = new TypeToken<List<Tugas>>(){}.getType();
            List<Tugas> list = gson.fromJson(json, listType);
            return list != null ? list : new ArrayList<>();
        } catch (Exception e) {
            System.err.println("Error loading tugas: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public static void saveTugas(List<Tugas> tugasList) {
        try {
            String json = gson.toJson(tugasList);
            Files.writeString(Path.of(DATA_PATH + "tugas.json"), json);
        } catch (IOException e) {
            System.err.println("Error saving tugas: " + e.getMessage());
        }
    }

    // ==================== ADAPTER ====================
    private static class LocalDateTimeAdapter implements JsonSerializer<LocalDateTime>, JsonDeserializer<LocalDateTime> {
        private final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        @Override
        public JsonElement serialize(LocalDateTime src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.format(formatter));
        }

        @Override
        public LocalDateTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return LocalDateTime.parse(json.getAsString(), formatter);
        }
    }
}